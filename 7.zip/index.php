<?php
session_start();
?>
<?php
$iWasThere=true;
include ('shared/core.lib.php');
$out=start('dev');
echo $out;
?>
