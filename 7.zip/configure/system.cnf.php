<?php
define( 'INSTALL_PATH',str_replace('index.php','',$_SERVER['SCRIPT_FILENAME']));
define( 'SITE_NAME',"UM El-Qura" );
define( 'AUTHUR',"El-Sayed G. AbdulAzem" );
define( 'VERSION',"0.1");
?>
