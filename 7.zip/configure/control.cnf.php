<?php
define('SCAFF',"your_table_name");
//NOTE:this array values cann't be the string 'scaff' OR 'Demo' these controller names are reserved for the framework basic installation.
//you can avoid this by removing these controllers if you don't need them. [after deployment]
$arInstldContrl=array(
          'default'=>'demo'
          ,'s'=>'scaff'
          ,SCAFF=>SCAFF
		);

?>
